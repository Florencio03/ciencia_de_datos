Fuente de los datos
https://www.gob.mx/salud/documentos/datos-abiertos-15212  

Archivi principal:
200419COVID19MEXICO.csv